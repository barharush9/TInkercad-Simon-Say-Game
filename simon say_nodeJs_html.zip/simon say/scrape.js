require('dotenv').config();
const puppeteer = require('puppeteer');
const express = require('express');
const app = express();
const port = 4003;
const fs = require('fs');

let browser;
let page;

// Serve static files from 'public' folder
app.use(express.static('public'));

// Function to initialize Puppeteer and start the simulation
const initializePuppeteer = async () => {
    if (browser) return; // Avoid reopening multiple browsers
    console.log('1');
    try {
        browser = await puppeteer.launch({ headless: false });
        console.log('Browser launched');
        page = await browser.newPage();
        console.log('New page created');
        
        // Go to the Tinkercad login page
        await page.goto('https://www.tinkercad.com/login', { waitUntil: 'networkidle2' });
        console.log('Navigated to Tinkercad login page');

        // Login to Tinkercad
        await page.click('#signInPersonalAccounts');
        await page.click('#autodeskProviderButton');
        console.log('Clicked login buttons');
        await page.waitForSelector('#userName', { visible: true, timeout: 10000 });
        await page.type('#userName', process.env.TINKERCAD_EMAIL);
        await page.click('#verify_user_btn');
    
        await page.waitForSelector('#password', { visible: true, timeout: 10000 });
        await page.type('#password', process.env.TINKERCAD_PASSWORD);
        await page.click('#btnSubmit');

        // Wait for navigation after login
        await page.waitForNavigation({ waitUntil: 'networkidle2' });
        console.log('Logged in successfully');

        // Navigate to the specific Tinkercad project
        await page.goto('https://www.tinkercad.com/things/eiaWiPde3fy-copy-of-copy-of-final-project-simon-says/editel?sharecode=qXEuBHrMJMriBTqGua7cm70NTIejei1VgKwV62x370k', { waitUntil: 'networkidle2' });
        console.log('Navigated to Tinkercad project');

        // Start the simulation
        await page.waitForSelector('#SIMULATION_ID', { timeout: 10000 });
        await page.click('#SIMULATION_ID');
        console.log('Simulation started');

    } catch (error) {
        console.error('Initialization Error:', error);
        throw error; // Rethrow the error to be caught in the endpoint
    }
};


// Function to extract level from serial data
const extractLevelFromSerialData = (serialData) => {
    const levelPattern = /Level:\s*(\d+)/i;
    const match = serialData.match(levelPattern);
    return match ? parseInt(match[1], 10) : null;
};

// Function to read and update the highest level from a file
const getAndUpdateHighestLevel = (level) => {
    const filePath = 'highestLevel.txt';
    let highestLevel = 0;

    if (fs.existsSync(filePath)) {
        highestLevel = parseInt(fs.readFileSync(filePath, 'utf8'), 10);
    }

    if (level !== null && level > highestLevel) {
        fs.writeFileSync(filePath, level.toString());
        highestLevel = level;
    }

    return highestLevel;
};

// Endpoint to fetch serial data and update highest level
app.get('/serial-data', async (req, res) => {
    try {
        if (!page) await initializePuppeteer(); // Initialize if not already done

        // Function to get serial data
        const getSerialData = async () => {
            return page.evaluate(() => {
                const contentDiv = document.querySelector('.code_panel__serial__content__text');
                return contentDiv ? contentDiv.innerText.trim() : 'No data';
            });
        };

        const serialData = await getSerialData();
        const level = extractLevelFromSerialData(serialData);

        // Update and get the highest level
        const highestLevel = getAndUpdateHighestLevel(level);

        res.json({ data: serialData, highestLevel });

    } catch (error) {
        console.error('Error fetching serial data:', error);
        res.status(500).send('Error fetching serial data');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
    initializePuppeteer();
});
